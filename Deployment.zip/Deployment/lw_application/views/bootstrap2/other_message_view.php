<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
/**
	 * other messages view
	 *
	 * @package		JQuery PHP Store/Shop
	 * @author		Vinod
	 * @copyright	Copyright (c) 2013, LivelyWorks. (http://livelyworks.net)
	 * @link		http://livelyworks.net
	 * @since		Version 1.0
*/
?>
<h4><?php if(isset($show_msg)) echo $show_msg; ?></h4>
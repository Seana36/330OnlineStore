<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
	 * Store Techs Config File
	 *
	 * @package		JQuery PHP Store/Shop
	 * @author		Vinod
	 * @copyright	Copyright (c) 2013, LivelyWorks. (http://livelyworks.net)
	 * @link		http://livelyworks.net
	 * @since		Version 1.2
*/

$config['available_themes']	= array('bootstrap2', 'bootstrap3');